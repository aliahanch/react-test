import React, {Component} from 'react';

class Default extends Component {
    render() {
        return (
            <div>
                <p>defult</p>
            </div>
        );
    }
}

export default Default;
